<?php include('partilas/menu.php'); ?>

<div class="main-content">
    <div class="wrapper">
        <h1>Manage Food</h1>

        
        <br /><br />

<!-- Button to Add Admin -->
<a href="#" class="btn-primary">Add Food</a>

<br /><br />

<table class="tbl-full">
  <tr>
    <th>No.</th>
    <th>Title</th>
    <th>Price</th>
    <th>Image</th>
    <th>Featured</th>
    <th>Active</th>
    <th>Actions</th>
  </tr>

  <tr>
    <td>1.</td>
    <td>Egg Rice</td>
    <td>Rs.1200.00</td>
    <td>--</td>
    <td>Yes</td>
    <td>Yes</td>
    <td>
        <a href="#" class="btn-secondary">Update Food</a>
        <a href="#" class="btn-danger">Delete Food</a>
    </td>
  </tr>

  <tr>
    <td>2.</td>
    <td>Chicken Rice</td>
    <td>Rs.1400.00</td>
    <td>--</td>
    <td>Yes</td>
    <td>Yes</td>
    <td>
        <a href="#" class="btn-secondary">Update Food</a>
        <a href="#" class="btn-danger">Delete Food</a>
    </td>
  </tr>

  <tr>
    <td>3.</td>
    <td>Sea Food Rice</td>
    <td>Rs.1500.00</td>
    <td>--</td>
    <td>Yes</td>
    <td>Yes</td>
    <td>
        <a href="#" class="btn-secondary">Update Food</a>
        <a href="#" class="btn-danger">Delete Food</a>
    </td>
  </tr>

  <tr>
    <td>4.</td>
    <td>Egg Kottu</td>
    <td>Rs.1000.00</td>
    <td>--</td>
    <td>Yes</td>
    <td>Yes</td>
    <td>
        <a href="#" class="btn-secondary">Update Food</a>
        <a href="#" class="btn-danger">Delete Food</a>
    </td>
  </tr>

</table>

    </div>

</div>

<?php include('partilas/footer.php'); ?>
<?php include('partilas/menu.php'); ?>

<div class="main-content">
    <div class="wrapper">
        <h1>Manage Category</h1>

        
        <br /><br />

<!-- Button to Add Admin -->
<a href="#" class="btn-primary">Add Category</a>

<br /><br />

<table class="tbl-full">
  <tr>
    <th>No.</th>
    <th>Title</th>
    <th>Image</th>
    <th>Featued</th>
    <th>Active</th>
    <th>Actions</th>
  </tr>

  <tr>
    <td>1.</td>
    <td>Pizza</td>
    <td>--</td>
    <td>Yes</td>
    <td>Yes</td>
    <td>
        <a href="#" class="btn-secondary">Update Categorie</a>
        <a href="#" class="btn-danger">Delete Categorie</a>
    </td>
  </tr>

  <tr>
    <td>2.</td>
    <td>Kottu</td>
    <td>--</td>
    <td>Yes</td>
    <td>Yes</td>
    <td>
        <a href="#" class="btn-secondary">Update Categorie</a>
        <a href="#" class="btn-danger">Delete Categorie</a>
    </td>
  </tr>

  <tr>
    <td>3.</td>
    <td>Rice</td>
    <td>--</td>
    <td>Yes</td>
    <td>Yes</td>
    <td>
        <a href="#" class="btn-secondary">Update Categorie</a>
        <a href="#" class="btn-danger">Delete Categorie</a>
    </td>
  </tr>

  <tr>
    <td>4.</td>
    <td>Noodles</td>
    <td>--</td>
    <td>Yes</td>
    <td>Yes</td>
    <td>
        <a href="#" class="btn-secondary">Update Categorie</a>
        <a href="#" class="btn-danger">Delete Categorie</a>
    </td>
  </tr>

  <tr>
    <td>5.</td>
    <td>Sandwich</td>
    <td>--</td>
    <td>Yes</td>
    <td>Yes</td>
    <td>
        <a href="#" class="btn-secondary">Update Categorie</a>
        <a href="#" class="btn-danger">Delete Categorie</a>
    </td>
  </tr>

</table>

    </div>

</div>

<?php include('partilas/footer.php'); ?>
        <!-- Footer Section Starts -->
        <div class="footer">
            <div class="wrapper">
                <p class="text-center">2023 All right reserved, wowoFood Restaurant.</p>
            </div>
        </div>
        <!-- Footer Section Ends -->



    </body>
</html>